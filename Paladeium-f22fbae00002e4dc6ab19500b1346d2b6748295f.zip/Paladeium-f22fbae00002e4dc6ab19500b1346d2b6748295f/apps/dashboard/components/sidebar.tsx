'use client'
import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { useState } from 'react'
import { Store, LogOut, type LucideIcon } from 'lucide-react'

const nav: { label: string; href: string; icon: LucideIcon }[] = [
  { label: 'Restaurants', href: '/restaurants', icon: Store },
]

export default function Sidebar() {
  const path = usePathname()
  const router = useRouter()
  const [loggingOut, setLoggingOut] = useState(false)

  async function handleLogout() {
    setLoggingOut(true)
    await fetch('/api/auth/logout', { method: 'POST' })
    router.push('/login')
    router.refresh()
  }

  return (
    <aside className="w-60 shrink-0 bg-[#0F0F1A] border-r border-white/5 flex flex-col">
      <div className="px-6 py-5 border-b border-white/5">
        <div className="text-[#D4A853] font-bold text-lg tracking-widest uppercase">Paladeium</div>
        <div className="text-white/30 text-[11px] mt-0.5 tracking-wide">Admin Dashboard</div>
      </div>

      <nav className="flex-1 p-3 space-y-0.5">
        {nav.map(item => {
          const active = path.startsWith(item.href)
          const Icon = item.icon
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                active
                  ? 'bg-[#D4A853]/10 text-[#D4A853] border border-[#D4A853]/20'
                  : 'text-white/50 hover:text-white/80 hover:bg-white/[0.04]'
              }`}
            >
              <Icon className="size-4 shrink-0" />
              <span>{item.label}</span>
            </Link>
          )
        })}
      </nav>

      <div className="px-5 py-4 border-t border-white/5 space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-white/25 text-xs">v1.0 MVP</span>
        </div>
        <button
          onClick={handleLogout}
          disabled={loggingOut}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-xs text-white/40 hover:text-white/70 hover:bg-white/[0.04] transition-all disabled:opacity-50"
        >
          <LogOut className="size-3.5 shrink-0" />
          <span>{loggingOut ? 'Signing out…' : 'Sign out'}</span>
        </button>
      </div>
    </aside>
  )
}
